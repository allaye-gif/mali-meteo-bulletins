import { createFileRoute } from "@tanstack/react-router";
import headerImg from "@/assets/header-full.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bulletin matinal du 07 juillet 2026 — Mali-Météo" },
      {
        name: "description",
        content:
          "Bulletin météorologique matinal du 07 juillet 2026 — Agence Nationale de la Météorologie du Mali (Mali-Météo).",
      },
    ],
  }),
  component: Index,
});

const FONT = '"Segoe UI", "Liberation Sans", Arial, Helvetica, sans-serif';

type Cell = { ville: string; tmax: number };

const rows: Cell[][] = [
  [
    { ville: "Kayes", tmax: 37 },
    { ville: "Koulikoro", tmax: 34 },
    { ville: "Sikasso", tmax: 32 },
    { ville: "Ségou", tmax: 36 },
    { ville: "Mopti", tmax: 37 },
    { ville: "Tombouctou", tmax: 41 },
  ],
  [
    { ville: "Gao", tmax: 43 },
    { ville: "Ménaka", tmax: 42 },
    { ville: "Kidal", tmax: 44 },
    { ville: "Taoudéni", tmax: 46 },
    { ville: "Bougouni", tmax: 34 },
    { ville: "Koutiala", tmax: 34 },
  ],
  [
    { ville: "Dioïla", tmax: 33 },
    { ville: "Nioro", tmax: 36 },
    { ville: "Nara", tmax: 37 },
    { ville: "Kita", tmax: 33 },
    { ville: "San", tmax: 35 },
    { ville: "Douentza", tmax: 38 },
  ],
  [
    { ville: "Bandiagara", tmax: 37 },
    { ville: "Bamako", tmax: 33 },
  ],
];

function TempTable({ data }: { data: Cell[] }) {
  const totalCols = 1 + data.length;
  const colWidth = `${100 / 7}%`;
  return (
    <table
      className="mb-4 border-collapse"
      style={{ width: `${(totalCols / 7) * 100}%`, tableLayout: "fixed" }}
    >
      <colgroup>
        {Array.from({ length: totalCols }).map((_, i) => (
          <col key={i} style={{ width: colWidth }} />
        ))}
      </colgroup>
      <tbody>
        <tr>
          <td
            className="text-center py-3 text-[15px] text-black"
            style={{ background: "#c9c9c9", border: "2px solid #ffffff" }}
          >
            Ville
          </td>
          {data.map((c, i) => (
            <td
              key={i}
              className="text-center py-3 text-[15px] text-black"
              style={{ background: "#c9c9c9", border: "2px solid #ffffff" }}
            >
              {c.ville}
            </td>
          ))}
        </tr>
        <tr>
          <td
            className="text-center py-3 text-[15px] text-black"
            style={{ background: "#d9a066", border: "2px solid #ffffff" }}
          >
            Tmax (°C)
          </td>
          {data.map((c, i) => (
            <td
              key={i}
              className="text-center py-3 text-[15px] text-black"
              style={{ background: "#d9a066", border: "2px solid #ffffff" }}
            >
              {c.tmax}
            </td>
          ))}
        </tr>
      </tbody>
    </table>
  );
}

function Index() {
  return (
    <div
      className="min-h-screen bg-white flex justify-center py-6"
      style={{ fontFamily: FONT }}
    >
      <div className="w-full max-w-[900px] bg-white shadow-lg" style={{ fontFamily: FONT }}>
        <img src={headerImg} alt="Mali Météo" className="w-full block" />

        <div
          className="text-white px-6 py-2 flex justify-between items-center"
          style={{ background: "#2e74b5", fontFamily: FONT }}
        >
          <span className="text-[15px]">Bulletin matinal du 07 juillet 2026</span>
          <span className="text-[15px] italic">Valide jusqu'à 18h TU</span>
        </div>

        <div className="px-8 py-6" style={{ fontFamily: FONT }}>
          <h2
            className="text-[26px] font-bold mb-3"
            style={{ color: "#2e74b5", fontFamily: FONT }}
          >
            Situation générale
          </h2>

          <div
            className="p-6 text-[15px] leading-[1.9] text-black text-justify"
            style={{ border: "2px solid #2e74b5", fontFamily: FONT }}
          >
            <p className="font-bold mb-4">Le temps sera marqué par :</p>
            <p className="mb-3">
              • un ciel <strong>nuageux à localement couvert</strong> sur l'ensemble du pays ;
            </p>
            <p className="mb-3">
              • des <strong>vents de mousson</strong> d'intensité{" "}
              <strong>faible à modérée</strong> dans toutes les régions et le District de Bamako,
              sauf le Nord de la région de Taoudéni où il y aura des{" "}
              <strong>vents d'harmattan</strong> de même intensité ;
            </p>
            <p className="mb-3">
              • une <strong>visibilité assez bonne</strong> dans l'ensemble, sauf au Nord du pays
              où elle sera parfois <strong>affectée par la poussière en suspension</strong> ;
            </p>
            <p className="mb-3">
              • des <strong>orages isolés</strong> accompagnés de pluies au cours de l'
              <strong>après-midi et durant la nuit</strong> sur l'
              <strong>ensemble du pays</strong>, y compris le{" "}
              <strong>District de Bamako</strong>, à l'exception du{" "}
              <strong>nord des régions de Taoudéni, Tombouctou et Kidal</strong> ;
            </p>
            <p>
              • des <strong>températures en légère hausse</strong> par rapport à celles observées
              hier dans tout le pays.
            </p>
          </div>

          <h2
            className="text-[26px] font-bold mt-8 mb-5"
            style={{ color: "#c86a1f", fontFamily: FONT }}
          >
            Prévision des températures maximales de la journée
          </h2>

          {rows.map((r, i) => (
            <TempTable key={i} data={r} />
          ))}
        </div>

        <div
          className="text-white text-center px-6 py-3 text-[13px] leading-[1.7]"
          style={{ background: "#2e74b5", fontFamily: FONT }}
        >
          <p>
            <strong>Agence Nationale de la Météorologie</strong> (MALI-METEO) sise Zone
            Aéroportuaire de Bamako-Sénou
          </p>
          <p>
            BP : 237 | Tél. (223) 20 20 62 04 | Fax : (223) 20 20 21 10 |{" "}
            <strong>malimeteo@malimeteo.ml</strong>
          </p>
        </div>
      </div>
    </div>
  );
}
